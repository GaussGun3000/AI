#pragma once
#include <QVector>

class GameState
{
	GameState();
	GameState(QVector<QVector<int>>& state);
	void setState(const QVector<QVector<int>>& state);

};

